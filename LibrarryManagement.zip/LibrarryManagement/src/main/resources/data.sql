
INSERT INTO user_info VALUES
  (1, 'Charu', '36764','Librarian', null);
  
  INSERT INTO book_info VALUES
  (1, 'Java', 'Programming','12', 'Oracle',0,1,null);
 