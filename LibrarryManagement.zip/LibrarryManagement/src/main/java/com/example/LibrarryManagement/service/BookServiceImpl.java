package com.example.LibrarryManagement.service;

import com.example.LibrarryManagement.model.Book;
import com.example.LibrarryManagement.model.BookResponse;
import com.example.LibrarryManagement.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepository bookRepo;

	@Override
	public void addBook(Book book) {

	}
	
	public List<Book> getBooks(){
		return bookRepo.findAll();
	}

}
