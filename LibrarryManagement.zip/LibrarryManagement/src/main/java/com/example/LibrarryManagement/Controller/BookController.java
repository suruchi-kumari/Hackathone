package com.example.LibrarryManagement.Controller;

import com.example.LibrarryManagement.model.Book;
import com.example.LibrarryManagement.service.BookService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller	
public class BookController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	BookService bookService;

	@RequestMapping(value= "/book",method=RequestMethod.POST)
	ResponseEntity createBook(@RequestBody Book book)
	{
		ResponseEntity<Book> rs=new ResponseEntity<Book>(book,HttpStatus.CREATED);
		bookService.addBook(book);
		return rs;
	};
	
/*	@RequestMapping(value= "/reports",method=RequestMethod.GET)
	ResponseEntity getBooks()
	{
		Book bookResponse = (Book) bookService.getBooks();
		ResponseEntity<Book> rs = new ResponseEntity<Book>(bookResponse,HttpStatus.OK);
		return rs;
	};*/
	
	
	@GetMapping("/viewBooks")
	public String listOfIssues(Model model) {
		List<Book> bookList = bookService.getBooks();
		model.addAttribute("bookList", bookList);
		return "viewBooks";
	}
}
