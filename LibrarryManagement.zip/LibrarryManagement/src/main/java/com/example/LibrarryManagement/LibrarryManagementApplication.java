package com.example.LibrarryManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarryManagementApplication.class, args);
	}

}
