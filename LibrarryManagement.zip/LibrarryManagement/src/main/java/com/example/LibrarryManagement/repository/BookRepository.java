package com.example.LibrarryManagement.repository;

import com.example.LibrarryManagement.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book,Long>{

	Book findByName(String name);
	
}
