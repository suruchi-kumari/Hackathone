package com.example.LibrarryManagement.service;

import com.example.LibrarryManagement.model.Book;

import java.util.List;

public interface BookService {
	void addBook(Book book);
	
	public List<Book> getBooks();
}
